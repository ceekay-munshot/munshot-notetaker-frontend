import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'node:path'

// Visual-shell build: this is a pure front-end prototype. There is no backend —
// the data layer (src/lib/api.ts) resolves entirely from in-memory mock data, so
// the dev server only needs to serve the Vite app. (The previous live-feed +
// summary API middleware, which proxied to ./server/*, has been removed along
// with the backend.)
export default defineConfig({
  plugins: [react()],
  // Bind on all interfaces and honor the PORT assigned by the preview harness so
  // a hosted preview can reach the dev server. allowedHosts lets a proxied
  // preview hostname through Vite's host-header check.
  server: {
    host: true,
    port: Number(process.env.PORT) || 5173,
    strictPort: false,
    allowedHosts: true,
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
})
